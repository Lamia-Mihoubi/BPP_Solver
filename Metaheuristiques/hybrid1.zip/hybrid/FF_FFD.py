# First-fit Algorithm
from docutils.nodes import list_item

from Functions1 import Bin
from Instances_generator import generate_obj_list2
def first_fit(list_items, max_size):
    """ Returns list of bins with input items inside. """
    list_bins = []
    list_bins.append(Bin())  # Add first empty bin_ to list

    for item in list_items:
        # Go through bins and try to allocate
        alloc_flag = False

        for bin_ in list_bins:
            if bin_.sum() + item <= max_size:
                bin_.addItem(item)
                alloc_flag = True
                break

        # If item not allocated in bins in list, create new bin_
        # and allocate it to it.
        if alloc_flag == False:
            newBin = Bin()
            newBin.addItem(item)
            list_bins.append(newBin)

    # Turn bins into list of items and return
    list_items = []
    for bin_ in list_bins:
        list_items.append(bin_.show())

    return (list_items)
#une nouvelle version utilisée pr l Hybridation
def first_fit2(list_items, max_size):
    """ Returns list of bins with input items inside. """
    list_bins = []
    indices=[]
    nb_bin=0
    list_bins.append(Bin())  # Add first empty bin_ to list
    i=0

    for item in list_items:

        # Go through bins and try to allocate
        alloc_flag = False

        for bin_ in list_bins:
            if bin_.sum() + item.weight <= max_size:
                bin_.addItem(item.weight)
                indices.append((item.id,item.weight,list_bins.index(bin_)))
                alloc_flag = True
                break

        # If item not allocated in bins in list, create new bin_
        # and allocate it to it.
        if alloc_flag == False:
            newBin = Bin()
            nb_bin += 1
            indices.append((item.id,item.weight, nb_bin))
            newBin.addItem(item.weight)
            list_bins.append(newBin)
        i+=1

    # Turn bins into list of items and return
    list_items = []
    for bin_ in list_bins:
        list_items.append(bin_.show())

    indices.sort(key=lambda tup: tup[2])

    zipped = indices

    unzipped_object = zip(*zipped)

    unzipped_list = list(unzipped_object)

    indices =  list(unzipped_list[0])

    return list_items, indices

# First-fit Decreasing Algorithm
# Sort values into decreasing order.
# Then apply first-fit algorithm.
def first_fit_dec(list_items, max_size):
    """ Returns list of bins with input items inside. """
    # Sort list in decreasing order
    list_items.sort(reverse=True)

    # Apply first-fit algorith
    return(first_fit(list_items, max_size))
def first_fit_dec2(list_items, max_size):
    """ Returns list of bins with input items inside. """
    # Sort list in decreasing order
    list_items.sort(reverse=True)

    # Apply first-fit algorith
    return(first_fit2(generate_obj_list2(list_items,len(list_items)), max_size))
